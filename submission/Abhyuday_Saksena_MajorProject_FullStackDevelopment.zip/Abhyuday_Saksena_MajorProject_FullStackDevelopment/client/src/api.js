import { auth } from './firebase';

const BASE = `${(import.meta.env.VITE_API_URL || '').trim().replace(/\/+$/, '')}/api`;

export async function api(path, { method = 'GET', body } = {}) {
  const token = await auth.currentUser?.getIdToken();
  const isForm = body instanceof FormData;
  let res;
  try {
    res = await fetch(`${BASE}${path}`, {
      method,
      headers: {
        ...(!isForm && { 'Content-Type': 'application/json' }),
        ...(token && { Authorization: `Bearer ${token}` }),
      },
      body: body ? (isForm ? body : JSON.stringify(body)) : undefined,
    });
  } catch {
    throw new Error('Cannot reach the server. It may be waking up (wait 30s and retry) or VITE_API_URL / CLIENT_URL is misconfigured.');
  }
  if (res.status === 204) return null;
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}
